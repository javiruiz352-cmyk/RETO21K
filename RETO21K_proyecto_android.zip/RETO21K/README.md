# RETO 21K — primera versión Android

Primera base nativa Android para registrar una carrera con GPS y guardar un historial local.

## Incluye en esta versión
- Inicio y finalización manual de una carrera.
- GPS en primer plano mientras la pantalla de la app está activa.
- Distancia estimada, tiempo y ritmo medio.
- Historial local persistente en el móvil, sin necesidad de Internet.

## Limitaciones importantes de esta versión inicial
- El registro GPS se detiene si Android cierra la actividad o la app pasa a segundo plano. Mantén la pantalla encendida durante la carrera.
- No incluye todavía mapa dibujado, servicio GPS en segundo plano, meteorología, sincronización en la nube ni plan de entrenamiento.
- La distancia depende de la calidad de la señal GPS y puede variar.
- No es una herramienta médica ni sustituye las indicaciones del profesional sanitario. Detén la actividad y consulta si aparecen síntomas nuevos o preocupantes.

## Cómo obtener el APK usando solo el móvil
1. Descarga este ZIP y descomprímelo si tu gestor de archivos lo permite.
2. Crea un repositorio nuevo en GitHub desde el navegador del móvil.
3. Sube el contenido de esta carpeta al repositorio (incluida la carpeta `.github`).
4. Abre la pestaña **Actions** del repositorio y ejecuta **Build RETO 21K APK**.
5. Cuando termine correctamente, entra en la ejecución y descarga el artefacto **RETO21K-debug-apk**.
6. Descomprime el artefacto y abre `app-debug.apk` en Android. Es posible que Android solicite permitir la instalación desde esa fuente.

Para una versión de publicación se deberá generar un APK firmado y probarlo en el dispositivo.
