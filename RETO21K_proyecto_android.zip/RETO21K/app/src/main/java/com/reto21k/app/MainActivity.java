package com.reto21k.app;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Locale;

public class MainActivity extends Activity implements LocationListener {
    private static final int LOCATION_PERMISSION = 21;
    private LocationManager locationManager;
    private TextView distanceView, timeView, paceView, statusView, historyView;
    private Button startButton, stopButton;
    private boolean running = false;
    private long startTime = 0L, elapsedBefore = 0L;
    private double distanceMeters = 0.0;
    private Location previousLocation;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private SharedPreferences prefs;

    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            if (running) {
                updateStats();
                handler.postDelayed(this, 1000);
            }
        }
    };

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("reto21k", MODE_PRIVATE);
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        buildScreen();
        showHistory();
    }

    private void buildScreen() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 36, 28, 28);
        root.setBackgroundColor(0xFF101820);
        scroll.addView(root);

        TextView title = text("RETO 21K", 30, 0xFFFFFFFF, true);
        root.addView(title);
        TextView subtitle = text("REGISTRO DE CARRERA · GPS", 13, 0xFF9FB3C8, true);
        root.addView(subtitle);

        root.addView(spacer(26));
        statusView = text("Listo para correr", 16, 0xFF7ED6A5, true);
        root.addView(statusView);

        distanceView = metric(root, "DISTANCIA", "0,00 km");
        timeView = metric(root, "TIEMPO", "00:00:00");
        paceView = metric(root, "RITMO MEDIO", "--:-- min/km");

        root.addView(spacer(18));
        startButton = new Button(this);
        startButton.setText("INICIAR CARRERA");
        root.addView(startButton);
        stopButton = new Button(this);
        stopButton.setText("FINALIZAR Y GUARDAR");
        stopButton.setEnabled(false);
        root.addView(stopButton);

        TextView note = text("Consejo: permite el acceso a la ubicación mientras usas la app y mantén la pantalla encendida durante esta primera versión.", 13, 0xFFB8C7D9, false);
        root.addView(spacer(14));
        root.addView(note);

        root.addView(spacer(28));
        root.addView(text("HISTORIAL RECIENTE", 18, 0xFFFFFFFF, true));
        historyView = text("Todavía no hay carreras guardadas.", 14, 0xFFB8C7D9, false);
        root.addView(historyView);

        startButton.setOnClickListener(v -> beginRun());
        stopButton.setOnClickListener(v -> finishRun());
        setContentView(scroll);
    }

    private TextView metric(LinearLayout root, String label, String value) {
        root.addView(spacer(18));
        root.addView(text(label, 12, 0xFF9FB3C8, true));
        TextView v = text(value, 34, 0xFFFFFFFF, true);
        root.addView(v);
        return v;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(null, android.graphics.Typeface.BOLD);
        t.setGravity(Gravity.START);
        return t;
    }

    private TextView spacer(int height) {
        TextView s = new TextView(this);
        s.setHeight(height);
        return s;
    }

    private void beginRun() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, LOCATION_PERMISSION);
            return;
        }
        distanceMeters = 0;
        previousLocation = null;
        elapsedBefore = 0;
        startTime = System.currentTimeMillis();
        running = true;
        startButton.setEnabled(false);
        stopButton.setEnabled(true);
        statusView.setText("GPS activo · carrera en curso");
        try {
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 2000, 2, this, Looper.getMainLooper());
            handler.post(ticker);
        } catch (SecurityException e) {
            Toast.makeText(this, "No se pudo acceder al GPS. Revisa los permisos.", Toast.LENGTH_LONG).show();
            running = false;
        }
    }

    private void finishRun() {
        if (!running) return;
        running = false;
        handler.removeCallbacks(ticker);
        try { locationManager.removeUpdates(this); } catch (SecurityException ignored) {}
        long seconds = (System.currentTimeMillis() - startTime) / 1000;
        String entry = String.format(Locale.getDefault(), "%.2f km · %s · %s",
                distanceMeters / 1000.0, formatTime(seconds), formatPace(seconds, distanceMeters));
        String old = prefs.getString("history", "");
        String updated = entry + (old.isEmpty() ? "" : "\n" + old);
        prefs.edit().putString("history", updated).apply();
        statusView.setText("Carrera guardada en este móvil");
        startButton.setEnabled(true);
        stopButton.setEnabled(false);
        showHistory();
        updateStats();
    }

    @Override public void onLocationChanged(Location location) {
        if (!running || location == null) return;
        if (location.hasAccuracy() && location.getAccuracy() > 35) return;
        if (previousLocation != null) {
            float segment = previousLocation.distanceTo(location);
            // Filter implausible GPS jumps; this is a conservative display filter.
            if (segment >= 0 && segment < 100) distanceMeters += segment;
        }
        previousLocation = location;
        updateStats();
    }

    private void updateStats() {
        long seconds = (System.currentTimeMillis() - startTime) / 1000;
        distanceView.setText(String.format(Locale.getDefault(), "%.2f km", distanceMeters / 1000.0));
        timeView.setText(formatTime(seconds));
        paceView.setText(formatPace(seconds, distanceMeters));
    }

    private String formatPace(long seconds, double meters) {
        if (meters < 20) return "--:-- min/km";
        double pace = seconds / (meters / 1000.0);
        long mins = (long) (pace / 60);
        long secs = Math.round(pace % 60);
        if (secs == 60) { mins++; secs = 0; }
        return String.format(Locale.getDefault(), "%d:%02d min/km", mins, secs);
    }

    private String formatTime(long seconds) {
        long h = seconds / 3600, m = (seconds % 3600) / 60, s = seconds % 60;
        return String.format(Locale.getDefault(), "%02d:%02d:%02d", h, m, s);
    }

    private void showHistory() {
        String h = prefs.getString("history", "");
        historyView.setText(h.isEmpty() ? "Todavía no hay carreras guardadas." : h);
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == LOCATION_PERMISSION && results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) {
            beginRun();
        } else {
            Toast.makeText(this, "El GPS necesita permiso de ubicación.", Toast.LENGTH_LONG).show();
        }
    }

    @Override protected void onPause() {
        super.onPause();
        // This starter version records GPS while the activity remains active.
    }
    @Override public void onProviderEnabled(String provider) {}
    @Override public void onProviderDisabled(String provider) {
        if (LocationManager.GPS_PROVIDER.equals(provider)) statusView.setText("Activa la ubicación del móvil");
    }
    @Override public void onStatusChanged(String provider, int status, Bundle extras) {}
}
